import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from genomedefineradv import *
import pickle
#Basic one cell movement plotted outputs
size = 128
savename = "optimised2500"
def cellmove(x,y,cell,timestep):#CELLMOVE CANNOT BE MOVED TO GENOME BECAUSE COLLISION NOT DEFINED THERE
    
    changex = 0
    changey = 0
    neuronss = [0 for i in range(len(inputs))]
    neuronsi = [0 for i in range(len(internal))]
    neuronst = [0 for i in range(len(outputs))]
    #Prep sensor neurons
    neuronss[0] = 1
    neuronss[5] = timestep/time_steps#gives the proportional age for seasonal movement changes
    #nsew 2345
    #neurons[4] = 1 if x==0 else (1 if collision[x-1][y] != 0)
    #neurons[5] = 1 if x==127 else 1 if collision[x+1][y] != 0
    #neurons[2] = 1 if y==127 else 1 if collision[x][y+1] != 0
    #neurons[3] = 1 if y==0 else 1 if collision[x][y-1] != 0
    #returns the nsew blocked or not
    if x==0:
        neuronss[4] =1
    elif collision[x-1][y] != 0:
        neuronss[9] = 1
    if x==size - 1  :
        neuronss[3] = 1
    elif collision[x+1][y] != 0:
        neuronss[8] = 1 
    if y==size - 1:
        neuronss[1] = 1
    elif collision[x][y+1] != 0:
        neuronss[6] = 1
    if y==0:
        neuronss[2] = 1
    elif collision[x][y-1] != 0:
        neuronss[7] = 1
    if x<127 and x>0 and y<127 and y>0:
        if collision[x-1][y+1] == 1:
            neuronss[10] = 1
        if collision[x+1][y+1] == 1:
            neuronss[11] = 1
        if collision[x+1][y-1] == 1:
            neuronss[12] = 1
        if collision[x-1][y-1] == 1:
            neuronss[13] = 1
    
    for i in cell.genomes:
        additionvalue = 0
        if i.stype == 0:
            additionvalue = neuronss[i.source] *i.weight
        else:
            additionvalue = neuronsi[i.source] *i.weight
        if i.ttype == 0:

            neuronsi[i.target] += additionvalue
        else:
            neuronst[i.target] += additionvalue
    #print(neurons)
    #NEURONS PROCESSED THEN MOVEMENT TIME
    if neuronst[4]>1:#activate random movement
        changex += random.randint(-1,1)
        changey += random.randint(-1,1)
    if neuronst[0]>1:
        changey +=1
    if neuronst[1]>1:
        changey -=1
    if neuronst[2]>1:
        changex +=1
    if neuronst[3]>1:
        changex -=1

    return changex, changey
#for i in gelist:
    #print(i.source,i.target,i.weight)
idcounter = 0
celllist = []
collision = [[0 for i in range(size)] for j in range(size)]
wallx = []
wally = []
def adder(x,y):
    global wallx
    global wally
    wallx.append(x)
    wally.append(y)
for i in range(0,119,7):
    if i>120:
        break
    for j in range(30,35):
        collision[j][i] = 1
        adder(j,i)
        
        collision[j][i+4] = 1
        adder(j,i+4)
    for j in range(i,i+5):
        collision[30][j]=1
        adder(30,j)
for j in range(30,35):
    collision[j][119] = 1
    adder(j,119)
    collision[j][127] = 1
    adder(j,127)
for i in range(119,127):
    collision[30][i] = 1
    adder(30,i)
#HERE LOADS GENERATION#8000 works
with open(savename, "rb") as f:
    celllist = pickle.load(f)
    for i in range(len(celllist)):
        potentialx = random.randint(0,size-1)
        potentialy = random.randint(0,size-1)
        while not collision[potentialx][potentialy] == 0:
            potentialx = random.randint(0,size-1)
            potentialy = random.randint(0,size-1)
        collision[potentialx][potentialy] = celllist[i][2]
if False:
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    neurons[0] = 1
    for i in newcell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    print(neurons)
xlist = []
ylist = []
clist = []
xlist,ylist,clist = listtocoord(celllist)
#STARTING PLOTTING PART
time_steps = 130
fig, ax = plt.subplots()
marker_size = 3 #up this to make points more visible
tigger = 1
def animate(i):
    global tigger
    """ Perform animation step. """
    #important - the figure is cleared and new axes are added
    fig.clear()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False, xlim=(-1,size), ylim=(-1,size))
    #the new axes must be re-formatted
    
    # and the elements for this frame are added
    ax.text(0.02, 0.95, 'Time step = %d' % i, transform=ax.transAxes)
    xlist,ylist,clist = listtocoord(celllist)
    for i in range(len(celllist)):#handles cell movement including collision
        changex,changey = cellmove(celllist[i][0],celllist[i][1],celllist[i][2],tigger)
        initialx, initialy = celllist[i][0],celllist[i][1]
        finalx, finaly = celllist[i][0],celllist[i][1]

        if initialx + changex>size-1:
            changex = size-1-initialx
        if initialx + changex<0:
            changex = 0-initialx
        if initialy + changey>size-1:
            changey = size-1-initialy
        if initialy + changey<0:
            changey = 0-initialy
        if changex>0:
            forstep = 1
        elif changex<0:
            forstep = -1
        if changex!= 0:
            for j in range(1*forstep,(changex),forstep):
                if collision[initialx+j][finaly] != 0:
                    break
                else:
                    finalx = initialx+j     
        if changey>0:
            forstep = 1
        else:
            forstep = -1
        for j in range(1*forstep,changey,forstep):
            if collision[finalx][initialy+j] != 0:
                break
            else:
                finaly = initialy+j
        
        collision[initialx][initialy] = 0
        collision[finalx][finaly] = celllist[2]
        celllist[i][0] = finalx
        celllist[i][1] = finaly
        #celllist[i][0] += changex
        #celllist[i][1] += changey
    tigger += 1
    xlist,ylist,clist = listtocoord(celllist)
    s = ax.scatter(xlist,ylist, c = clist, marker = "s", edgecolor = None,s=marker_size)#HERES THE ERROR
    s2 = ax.scatter(wallx,wally, c = "#000000", marker = "s", edgecolor = None,s=marker_size)
    fig.colorbar(s)
    
   
    
print(xlist,ylist,clist)


plt.grid(b=None)
ani = animation.FuncAnimation(fig, animate, interval=100, frames=range(time_steps))
ani.save('onecell4.gif', writer='pillow')
