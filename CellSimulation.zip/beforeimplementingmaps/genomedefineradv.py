import random
import copy
numgenomes = 10
inputs =[0,1,2,3,4,5,6,7,8,9,10,11,12,13]
#0 is time cycle thus always 
#NEW ONE  0 same
#age is 5
#1234 nsew if its border
#6789 nsew is if its a physical wall
#10 12 13 14 topleft topright btmright btmleft
internal = [0,1,2,3,4]

outputs = [0,1,2,3,4]
#0123 are move nsew respectively or at least try to
#while  4 is random
numberofgenomes = 12
class genomes:
    #genome types and what they do

    
    
    def __init__(self,typeofsource,sourceid,typeoftarget,targetid,weight):
        self.source = sourceid
        self.stype = typeofsource
        self.ttype = typeoftarget
        self.target = targetid
        self.weight = weight
        
def generategenome():
    typeofsource = random.randint(0,3)
    if typeofsource <3 :#Thismeans that its asensor neuron
        typeofsource = 0
        sourceid = random.choice(inputs)
    else:
        typeofsource = 1
        sourceid = random.choice(internal)
    typeoftarget = random.randint(0,3)
    if typeoftarget ==0 :#this means output to internal
        typeoftarget = 0
        targetid = random.choice(internal)
    else:#output to action
        typeoftarget = 1
        targetid = random.choice(outputs)
    weight = random.uniform(-1.5,1.5)
    return typeofsource,sourceid,typeoftarget,targetid,weight
def generategenomelist():
    output = []#output genome list
    for i in range(0,numberofgenomes):
        typeofsource,sourceid,typeoftarget,targetid,weight = generategenome() 
        output.append(genomes(typeofsource,sourceid,typeoftarget,targetid,weight))    
    return output
#print(generategenomelist()[0].source)
class cells:#represents one cell
    #needs a colour a id 4 genomes 4 sensors and
    def __init__(self, name, colour, genomelist):
        self.id = name
        self.colour = colour
        self.genomes = genomelist
        #self.x = x
        #self.y =y
    
    
    
def listtocoord(arr):
    xlist2 = []
    ylist2 = []
    clist2 = []
    for i in arr:
        xlist2.append(i[0])
        ylist2.append(i[1])
        clist2.append(i[2].colour)
    return xlist2,ylist2,clist2

def mutation(cell):
    #mutation chance not determined here
    #print("yeayea",cell.colour)
    cell = copy.copy(cell)
    genomeid = random.randint(0,len(cell.genomes)-1)#chooses a random genome to rewrite
    determinant = random.randint(0,100)
    if determinant < 15:#This part means change source
        typeofsource = random.randint(0,3)
        if typeofsource <3 :#Thismeans that its asensor neuron
            cell.genomes[genomeid].stype = 0
            cell.genomes[genomeid].sourceid = random.choice(inputs)
        else:
            cell.genomes[genomeid].ttype = 1
            cell.genomes[genomeid].sourceid = random.choice(internal)
    elif determinant < 30:
        typeoftarget = random.randint(0,3)
        if typeoftarget == 0  :#Thismeans that its asensor neuron
            cell.genomes[genomeid].ttype = 0
            cell.genomes[genomeid].targetid = random.choice(internal)
        else:
            cell.genomes[genomeid].ttype = 1
            cell.genomes[genomeid].targetid = random.choice(outputs)
    else:
        cell.genomes[genomeid].weight += random.uniform(-1,1)
    cell.genomes.sort(key=lambda x: x.stype*100+x.source, reverse=False)#If i remember correctly it
    #sorts it so the running order is correct ,  first sensor, internal then output
    #now change cell hexadecimal colour
    cell.colour = cell.colour[1:]
    r = cell.colour[:2]
    r = min(int(r,16) + random.randint(-32,32),255)
    r = max(r,0)
    g = cell.colour[2:4]
    g = min(int(g,16) + random.randint(-32,32),255)
    g = max(g,0)
    b = cell.colour[4:6]
    b = min(int(b,16) + random.randint(-32,32),255)
    b = max(b,0)
    cell.colour = "#" + hex(r)[2:].zfill(2) + hex(g)[2:].zfill(2) + hex(b)[2:].zfill(2)
    return cell

#431007d
#60100ab
