from genomedefineradv import cell
print(cell("1","red"))
