for i in range(-1,-2,-1):
    print(i)
