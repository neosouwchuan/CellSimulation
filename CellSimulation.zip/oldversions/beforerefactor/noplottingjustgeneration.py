import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import pickle
from genomedefineradv import *
import copy
filesavename = "harsherconditionssaves/rectangle"
loadfromfile = True
def printoutcollision(collision):
    for i in collision:
        for j in i:
            if j == 0 or j == 1:
                print(j,end=" ")
            else:
                print("s",end=" ")
        print("")
#Basic one cell movement plotted outputs
size = 128
def cellmove(x,y,cell):#CELLMOVE CANNOT BE MOVED TO GENOME BECAUSE COLLISION NOT DEFINED THERE
    changex = 0
    changey = 0
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    #Prep sensor neurons
    neurons[0] = 1
    #nsew 2345
    #neurons[4] = 1 if x==0 else (1 if collision[x-1][y] != 0)
    #neurons[5] = 1 if x==127 else 1 if collision[x+1][y] != 0
    #neurons[2] = 1 if y==127 else 1 if collision[x][y+1] != 0
    #neurons[3] = 1 if y==0 else 1 if collision[x][y-1] != 0
    #returns the nsew blocked or not
    if x==0 :
        neurons[4] =1
    elif collision[x-1][y] != 0:
        neurons[4] =1
    if x==size - 1  :
        neurons[5] = 1
    elif collision[x+1][y] != 0:
        neurons[5] = 1
    if y==size - 1:
        neurons[2] = 1
    elif collision[x][y+1] != 0:
        neurons[2] = 1
    if y==0:
        neurons[3] = 1
    elif collision[x][y-1] != 0:
        neurons[3] = 1

    for i in cell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    #print(neurons)
    #NEURONS PROCESSED THEN MOVEMENT TIME
    if neurons[10]>1:#activate random movement
        changex += random.randint(-1,1)
        changey += random.randint(-1,1)
    if neurons[6]>1:
        changey +=1
    if neurons[7]>1:
        changey -=1
    if neurons[8]>1:
        changex +=1
    if neurons[9]>1:
        changex -=1

    return changex, changey
idcounter = 0
celllist = []
collision = [[0 for i in range(size)] for j in range(size)]
#THIS PART MAKES THE WALLS
for i in range(10,60):
    collision[30][i]=1

for i in range(72,108):
    collision[30][i]=1
for i in range(30,35):
    collision[i][10]=1
    collision[i][59]=1
    collision[i][72]=1
    collision[i][109]=1
#THIS PART ENDS MAKING
print(collision[0][0])
if loadfromfile:#LOAD INSTEAD OF GENERATE
    with open(filesavename, "rb") as f:
        celllist = pickle.load(f)
        for i in range(len(celllist)):
            collision[celllist[i][0]][celllist[i][1]] = celllist[i][2]
else:
    for i in range(300):#generate cells
        gelist = generategenomelist()
        gelist.sort(key=lambda x: x.source, reverse=False)
        color = "%06x" % random.randint(0, 0xFFFFFF)
        newcell = cells(idcounter,"#"+color,gelist.copy())
        newcell = mutation(newcell)
        possiblex = random.randint(0,size-1)
        possibley = random.randint(0,size-1)
        while not collision[possiblex][possibley] == 0:
            possiblex = random.randint(0,size-1)
            possibley = random.randint(0,size-1)
        #possiblex = int(possiblex)
        #possibley = int(possibley)
        #print(newcell.colour)
        celllist.append([possiblex,possibley,newcell])#IMPORTANT LIST
        collision[possiblex][possibley] = newcell
        idcounter +=1
if False:
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    neurons[0] = 1
    for i in newcell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    print(neurons)
#STARTING GENERATION PART

def onegeneration(celllist): #wdyt
    time_steps = 146
    for timestep in range(time_steps):# run for n number generations
    #firstly populate with celllist
    #done nothing lol
    #then move
        for i in range(len(celllist)):#handles cell movement including collision
            changex,changey = cellmove(celllist[i][0],celllist[i][1],celllist[i][2])
            initialx, initialy = celllist[i][0],celllist[i][1]
            finalx, finaly = celllist[i][0],celllist[i][1]
            if initialx + changex>size - 1:
                changex = size - 1 -initialx
            if initialx + changex<0:
                changex = 0-initialx
            if initialy + changey>size - 1:
                changey = size - 1-initialy
            if initialy + changey<0:
                changey = 0-initialy
            if changex>0:
                for j in range(1,changex+1):
                    if  collision[initialx+j][finaly] != 0:
                        break
                    else:
                        finalx = initialx+j
            else:
                for j in range(-1,changex-1,-1):
                    if collision[initialx+j][finaly] != 0 :
                        break
                    else:
                        finalx = initialx+j
            if changey>0:
                for j in range(1,changey+1):
                    if collision[finalx][initialy+j] != 0:
                        break
                    else:
                        finaly = initialy+j
            else:
                for j in range(-1,changey-1,-1):
                    if collision[finalx][initialy+j] != 0:
                        break
                    else:
                        finaly = initialy+j
            collision[initialx][initialy] = 0
            
            collision[finalx][finaly] = celllist[2]
            
            celllist[i][0] = finalx
            celllist[i][1] = finaly
    #then check who survived
    #afterwards return celllist again to be populated and mutated
    #DEFINE SURVIVAL CONDITION HERE REMEMBER THAT COORD DOESNT MATTER AFTERWARDS
    # if the xposition is lesser than 15 survive and continue
    #reset collision here while celllist is definite along with aboth
    
    survived = []
    for i in range(len(celllist)):
        collision[celllist[i][0]][celllist[i][1]] = 0
        if(celllist[i][0]<10):
            survived.append(celllist[i][2])

    return survived
for i in range(0,18001):#Number of generations duh
    if i == 0:
        oldsurvived = []
        for j in celllist:
            oldsurvived.append(j[2])
    if i%100 == 0:
        print("generation",i)
    if i%500 == 0 and i!=0:
        with open(filesavename+str(i), 'wb') as f:
            pickle.dump(celllist, f)
    survived = onegeneration(celllist)
        
    # for j in collision:
    #     for k in j:
    #         if not(k == 0 or k== 1):
    #             print(k)
    #             print("wellshit")
    #             o+=1
    #print(type(survived[0]))
    #since survived acquired old celllist no longer needed
    celllist = []
    id = 0
    for j in range(100):#size of subsequent generations
        if len(survived)>10:
            newcell = random.choice(survived)
        else:
            newcell = random.choice(oldsurvived)
        if random.randint(1,100) < 10:

            newcell = copy.copy(mutation(newcell))
        possiblex = random.randint(0,size-1)
        possibley = random.randint(0,size-1)
        while not collision[possiblex][possibley] == 0:
            possiblex = random.randint(0,size-1)
            possibley = random.randint(0,size-1)
        #possiblex = int(possiblex)
        #possibley = int(possibley)
        celllist.append([possiblex,possibley,newcell])#IMPORTANT LIST
        collision[possiblex][possibley] = newcell
    if len(survived)>10:
        oldsurvived = survived
    idcounter +=1
    
    

with open(filesavename, 'wb') as f:
    pickle.dump(celllist, f)

time_steps = 60



