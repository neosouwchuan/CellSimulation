import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from genomedefineradv import *
import pickle
#Basic one cell movement plotted outputs
size = 128
savename = "harsherconditionssaves/rectangle6000"
def cellmove(x,y,cell):
    changex = 0
    changey = 0
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    
    #Prep sensor neurons
    neurons[0] = 1
    #nsew 2345
    #neurons[4] = 1 if x==0 else (1 if collision[x-1][y] != 0)
    #neurons[5] = 1 if x==127 else 1 if collision[x+1][y] != 0
    #neurons[2] = 1 if y==127 else 1 if collision[x][y+1] != 0
    #neurons[3] = 1 if y==0 else 1 if collision[x][y-1] != 0
    
    if x==0 :
        neurons[4] =1
    elif collision[x-1][y] != 0:
        neurons[4] =1
    if x==size-1 :
        neurons[5] = 1
    elif collision[x+1][y] != 0:
        neurons[5] = 1
    if y==size-1:
        neurons[2] = 1
    elif collision[x][y+1] != 0:
        neurons[2] = 1
    if y==0:
        neurons[3] = 1
    elif collision[x][y-1] != 0:
        neurons[3] = 1

    for i in cell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    #print(neurons)
    #NEURONS PROCESSED THEN MOVEMENT TIME
    if neurons[10]>1:#activate random movement
        changex += random.randint(-1,1)
        changey += random.randint(-1,1)
    if neurons[6]>1:
        changey +=1
    if neurons[7]>1:
        changey -=1
    if neurons[8]>1:
        changex +=1
    if neurons[9]>1:
        changex -=1

    return changex, changey

#for i in gelist:
    #print(i.source,i.target,i.weight)
idcounter = 0
celllist = []
collision = [[0 for i in range(size)] for j in range(size)]
wallx = []
wally = []
for i in range(10,60):
    wallx.append(30)
    wally.append(i)
    collision[30][i]=1
for i in range(72,110):
    wallx.append(30)
    wally.append(i)
    collision[30][i]=1
for i in range(30,35):
    wallx.append(i)
    wally.append(10)
    collision[i][10]=1
    wallx.append(i)
    wally.append(59)
    collision[i][59]=1
    wallx.append(i)
    wally.append(72)
    collision[i][72]=1
    wallx.append(i)
    wally.append(109)
    collision[i][109]=1
#HERE LOADS GENERATION#8000 works
with open(savename, "rb") as f:
    celllist = pickle.load(f)
    for i in range(len(celllist)):
        potentialx = random.randint(0,size-1)
        potentialy = random.randint(0,size-1)
        while not collision[potentialx][potentialy] == 0:
            potentialx = random.randint(0,size-1)
            potentialy = random.randint(0,size-1)
        collision[potentialx][potentialy] = celllist[i][2]
if False:
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    neurons[0] = 1
    for i in newcell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    print(neurons)
xlist = []
ylist = []
clist = []
xlist,ylist,clist = listtocoord(celllist)
#STARTING PLOTTING PART
time_steps = 130
fig, ax = plt.subplots()
marker_size = 3 #up this to make points more visible

def animate(i):
    
    """ Perform animation step. """
    #important - the figure is cleared and new axes are added
    fig.clear()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False, xlim=(-1,size), ylim=(-1,size))
    #the new axes must be re-formatted
    
    # and the elements for this frame are added
    ax.text(0.02, 0.95, 'Time step = %d' % i, transform=ax.transAxes)
    xlist,ylist,clist = listtocoord(celllist)
    for i in range(len(celllist)):#handles cell movement including collision
        changex,changey = cellmove(celllist[i][0],celllist[i][1],celllist[i][2])
        initialx, initialy = celllist[i][0],celllist[i][1]
        finalx, finaly = celllist[i][0],celllist[i][1]

        if initialx + changex>size-1:
            changex = size-1-initialx
        if initialx + changex<0:
            changex = 0-initialx
        if initialy + changey>size-1:
            changey = size-1-initialy
        if initialy + changey<0:
            changey = 0-initialy
        if changex>0:
            #changex = 1
            for j in range(1,changex+1):
                if  collision[initialx+j][finaly] != 0:
                    break
                else:
                    finalx = initialx+j
        elif changex<0:
            # j = -1
            # while (j >= changex):
            #     if collision[initialx+j][finaly] != 0:
            #         break
            #     finalx = initialx + j
            #     j -= 1
            #changex = -1
            for j in range(-1,changex-1,-1):
                if collision[initialx+j][finaly] != 0:
                    break
                else:
                    
                    finalx = initialx+j     
        # if finalx == 29 and finaly in range(72,98):
        #     print(initialx,initialy, changex,changey)
        if changey>0:
            for j in range(1,changey+1):
                if collision[finalx][initialy+j] != 0:
                    break
                else:
                    finaly = initialy+j
        else:
            for j in range(-1,changey-1,-1):
                
                if collision[finalx][initialy+j] != 0:
                    break
                else:
                    
                    finaly = initialy+j
        
        collision[initialx][initialy] = 0
        collision[finalx][finaly] = celllist[2]
        
        celllist[i][0] = finalx
        celllist[i][1] = finaly
        #celllist[i][0] += changex
        #celllist[i][1] += changey
    xlist,ylist,clist = listtocoord(celllist)
    s = ax.scatter(xlist,ylist, c = clist, marker = "s", edgecolor = None,s=marker_size)#HERES THE ERROR
    s2 = ax.scatter(wallx,wally, c = "#000000", marker = "s", edgecolor = None,s=marker_size)
    fig.colorbar(s)
   
    
print(xlist,ylist,clist)


plt.grid(b=None)
ani = animation.FuncAnimation(fig, animate, interval=100, frames=range(time_steps))
ani.save('onecell4.gif', writer='pillow')
