import random
numgenomes = 3
inputs =[0,1]
outputs = [1,2,3]
class genomes:
    #genome types and what they do
    #0 is time cycle
    #1 is internal addition neuron
    #2 is random movement
    #3 is move left
    
    #0 can only output
    # 1 can be both
    # 2 3 can only be input
    
    
    def __init__(self,sourceid,targetid,weight):
        self.source = sourceid
        self.target = targetid
        self.weight = weight
        
def generategenome():
    sourceid = random.choice(inputs)
    targetid = random.choice(outputs)
    while targetid == sourceid:
        targetid = random.choice(outputs)
    weight = random.uniform(-2,2)
    return sourceid,targetid,weight
def generategenomelist():
    combinations=[]#maintains preexisiting combinations to make sure no dupe
    output = []#output genome list
    for i in range(0,4):
        sourceid,targetid,weight=generategenome()
        while(str(sourceid)+str(targetid))in combinations:
            sourceid,targetid,weight=generategenome()
            #repeat till no repeat
        output.append(genomes(sourceid,targetid,weight))
        
        combinations.append(str(sourceid)+str(targetid))
    return output
#print(generategenomelist()[0].source)
class cells:#represents one cell
    #needs a colour a id 4 genomes 4 sensors and
    def __init__(self, name, colour, genomelist):
        self.id = name
        self.colour = colour
        self.genomes = genomelist
        #self.x = x
        #self.y =y
    
    
    
def listtocoord(arr):
    xlist2 = []
    ylist2 = []
    clist2 = []
    for i in arr:
        xlist2.append(i[0])
        ylist2.append(i[1])
        clist2.append(i[2].colour)
    return xlist2,ylist2,clist2
