import random
color = "%06x" % random.randint(0, 0xFFFFFF)
print(color)