import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import random
#https://www.py4u.net/discuss/260620
time_steps = 10
N_nodes = 50#useless just represents no. dots
x=np.random.randint(128,size=50)
y=np.random.randint(128,size=50)
fig, ax = plt.subplots()
marker_size = 3 #upped this to make points more visible

def animate(i):
    """ Perform animation step. """
    #important - the figure is cleared and new axes are added
    fig.clear()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False, xlim=(-1,128), ylim=(-1,128))
    #the new axes must be re-formatted

    # and the elements for this frame are added
    ax.text(0.02, 0.95, 'Time step = %d' % i, transform=ax.transAxes)
    s = ax.scatter(x,y, cmap = "RdBu_r", marker = "s", edgecolor = None,s=marker_size)
    for i in range(len(x)):
        x[i] += random.randint(-1,1)
    for i in range(len(y)):
        y[i] += random.randint(-1,1)
    fig.colorbar(s)



plt.grid(b=None)
ani = animation.FuncAnimation(fig, animate, interval=100, frames=range(time_steps))
ani.save('animation.gif', writer='pillow')
