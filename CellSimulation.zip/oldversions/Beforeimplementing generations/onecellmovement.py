import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from genomedefiner import *
numgenomes = 3
#Basic one cell movement plotted out

def cellmove(cell):
    changex = 0
    changey = 0
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    neurons[0] = 1
    for i in cell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    #print(neurons)
    #NEURONS PROCESSED THEN MOVEMENT TIME
    if neurons[2]>1:#activate random movement
        changex += random.randint(-1,1)
        changey += random.randint(-1,1)
    if neurons[3]>1:
        changex -= 1

    return changex, changey
gelist = generategenomelist()
gelist.sort(key=lambda x: x.source, reverse=False)
#for i in gelist:
    #print(i.source,i.target,i.weight)
newcell = cells(0,"#ffde00",gelist)
celllist = []
celllist.append([64,64,newcell])#IMPORTANT LIST
if True:
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    neurons[0] = 1
    for i in newcell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    print(neurons)
xlist = []
ylist = []
clist = []
xlist,ylist,clist = listtocoord(celllist)
#STARTING PLOTTING PART
time_steps = 30
fig, ax = plt.subplots()
marker_size = 3 #up this to make points more visible

def animate(i):
    
    """ Perform animation step. """
    #important - the figure is cleared and new axes are added
    fig.clear()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False, xlim=(-1,128), ylim=(-1,128))
    #the new axes must be re-formatted
    
    # and the elements for this frame are added
    ax.text(0.02, 0.95, 'Time step = %d' % i, transform=ax.transAxes)
    xlist,ylist,clist = listtocoord(celllist)
    
    s = ax.scatter(xlist,ylist, c = clist, marker = "s", edgecolor = None,s=marker_size)#HERES THE ERROR
    
    fig.colorbar(s)
   
    for i in range(len(celllist)):
        changex,changey = cellmove(celllist[i][2])
        celllist[i][0] += changex
        celllist[i][1] += changey
    xlist,ylist,clist = listtocoord(celllist)
print(xlist,ylist,clist)


plt.grid(b=None)
ani = animation.FuncAnimation(fig, animate, interval=100, frames=range(time_steps))
ani.save('onecell.gif', writer='pillow')
