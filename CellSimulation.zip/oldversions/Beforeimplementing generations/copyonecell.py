import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from genomedefiner import *

#Basic one cell movement plotted out

def cellmove(x,y,cell):
    changex = 0
    changey = 0
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    neurons[0] = 1
    for i in cell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    #print(neurons)
    #NEURONS PROCESSED THEN MOVEMENT TIME
    if neurons[2]>1:#activate random movement
        changex += random.randint(-1,1)
        changey += random.randint(-1,1)
    if neurons[3]>1:
        changex -= 1

    return changex, changey

#for i in gelist:
    #print(i.source,i.target,i.weight)
idcounter = 0
celllist = []
collision = [[0 for i in range(128)] for j in range(128)]
for i in range(100):
    gelist = generategenomelist()
    gelist.sort(key=lambda x: x.source, reverse=False)
    color = "%06x" % random.randint(0, 0xFFFFFF)
    newcell = cells(idcounter,"#"+color,gelist.copy())
    possiblex = random.randint(0,127)
    possibley = random.randint(0,127)
    while not collision[possiblex][possibley] == 0:
        possiblex = random.randint(0,127)
        possibley = random.randint(0,127)
    celllist.append([possiblex,possibley,newcell])#IMPORTANT LIST
    collision[possiblex][possibley] = newcell
    idcounter +=1
if True:
    neurons = []
    for i in range(numgenomes+1):
        neurons.append(0)
    neurons[0] = 1
    for i in newcell.genomes:
        neurons[i.target] = neurons[i.source]*i.weight
    print(neurons)
xlist = []
ylist = []
clist = []
xlist,ylist,clist = listtocoord(celllist)
#STARTING PLOTTING PART
time_steps = 30
fig, ax = plt.subplots()
marker_size = 3 #up this to make points more visible

def animate(i):
    
    """ Perform animation step. """
    #important - the figure is cleared and new axes are added
    fig.clear()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False, xlim=(-1,128), ylim=(-1,128))
    #the new axes must be re-formatted
    
    # and the elements for this frame are added
    ax.text(0.02, 0.95, 'Time step = %d' % i, transform=ax.transAxes)
    xlist,ylist,clist = listtocoord(celllist)
    
    s = ax.scatter(xlist,ylist, c = clist, marker = "s", edgecolor = None,s=marker_size)#HERES THE ERROR
    
    fig.colorbar(s)
   
    for i in range(len(celllist)):#handles cell movement including collision
        changex,changey = cellmove(celllist[i][0],celllist[i][1],celllist[i][2])
        initialx, initialy = celllist[i][0],celllist[i][1]
        finalx, finaly = celllist[i][0],celllist[i][1]
        if initialx + changex>127:
            changex = 127-initialx
        if initialx + changex<0:
            changex = 0-initialx
        if initialy + changey>127:
            changey = 127-initialy
        if initialy + changey<0:
            changey = 0-initialy
            
        for j in range(1,changex+1):
            if collision[initialx+j][finaly] == 0:
                finalx = initialx+j
        for j in range(1,changey+1):
            if collision[finalx][initialy+j] == 0:
                finaly = initialy+j
        collision[initialx][initialy] = 0
        collision[finalx][finaly] = celllist[2]
        
        celllist[i][0] = finalx
        celllist[i][1] = finaly
        #celllist[i][0] += changex
        #celllist[i][1] += changey
    xlist,ylist,clist = listtocoord(celllist)
print(xlist,ylist,clist)


plt.grid(b=None)
ani = animation.FuncAnimation(fig, animate, interval=100, frames=range(time_steps))
ani.save('onecell.gif', writer='pillow')
