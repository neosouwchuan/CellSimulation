import random
numgenomes = 10
inputs =[0,1,2,3,4,5]
#2,3,4,5 are if nsew are occupied respectively
#0 is time cycle thus always 
#1 is middle neuron
outputs = [1,6,7,8,9,10]
#6,7,8,9 are move nsew respectively or at least try to
#while  10 is random
numberofgenomes = 6
class genomes:
    #genome types and what they do

    
    
    def __init__(self,sourceid,targetid,weight):
        self.source = sourceid
        self.target = targetid
        self.weight = weight
        
def generategenome():
    sourceid = random.choice(inputs)
    targetid = random.choice(outputs)
    while targetid == sourceid:
        targetid = random.choice(outputs)
    weight = random.uniform(-2,2)
    return sourceid,targetid,weight
def generategenomelist():
    combinations=[]#maintains preexisiting combinations to make sure no dupe
    output = []#output genome list
    for i in range(0,numberofgenomes):
        sourceid,targetid,weight=generategenome()
        while(str(sourceid)+str(targetid))in combinations:
            sourceid,targetid,weight=generategenome()
            #repeat till no repeat
        output.append(genomes(sourceid,targetid,weight))
        
        combinations.append(str(sourceid)+str(targetid))
    return output
#print(generategenomelist()[0].source)
class cells:#represents one cell
    #needs a colour a id 4 genomes 4 sensors and
    def __init__(self, name, colour, genomelist):
        self.id = name
        self.colour = colour
        self.genomes = genomelist
        #self.x = x
        #self.y =y
    
    
    
def listtocoord(arr):
    xlist2 = []
    ylist2 = []
    clist2 = []
    for i in arr:
        xlist2.append(i[0])
        ylist2.append(i[1])
        clist2.append(i[2].colour)
    return xlist2,ylist2,clist2

def mutation(cell):
    #mutation chance not determined here
    genomeid = random.randint(0,numberofgenomes-1)
    determinant = random.randint(0,100)
    if determinant < 0.15:#This part means change source
        cell.genomes[genomeid].source = random.choice(inputs)
    elif determinant < 0.3:
        cell.genomes[genomeid].target = random.choice(outputs)
    else:
        cell.genomes[genomeid].weight += random.random()
    return cell