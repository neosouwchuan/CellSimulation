for i in range(1,0,0):
    print(i)
